package com.test.myapplication

@SingleTon
class logManager {
}